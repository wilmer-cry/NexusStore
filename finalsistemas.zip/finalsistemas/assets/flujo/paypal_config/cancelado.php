<?php
        header("Location: ../tienda_producto/prod_mostrar.php");
?>
