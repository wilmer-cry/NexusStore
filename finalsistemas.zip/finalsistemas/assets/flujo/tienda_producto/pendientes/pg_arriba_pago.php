<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Tienda</title>
    
    <link rel="icon"       href="../../img/fav.png" >
    <link rel="stylesheet" href="../../css/style.css">
    <link rel="stylesheet" href="../../css/header_tienda.css">
    <link rel="stylesheet" href="../../css/cuerpo_tienda.css">
    <link rel="stylesheet" href="../../css/cats.css">

    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=PT+Sans+Narrow&display=swap">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.2.0/css/all.min.css">
</head>
<body>