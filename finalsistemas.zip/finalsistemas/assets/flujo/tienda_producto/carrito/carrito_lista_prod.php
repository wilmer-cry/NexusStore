<?php
include'pg_head.php';
include'pg_header.php';
?>
<div class="container">
    <div class="column">
        <div class="row">
            texto contenido     </div>
    </div>
</div>
</body>
</html>
