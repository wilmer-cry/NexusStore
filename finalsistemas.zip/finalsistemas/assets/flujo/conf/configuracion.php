<?php
error_reporting(0);
ini_set('display_errors', 0);

$logFile = 'err.log';
ini_set('error_log', $logFile);
