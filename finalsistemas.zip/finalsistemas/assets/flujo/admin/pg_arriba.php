<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>NEXUS</title>
    <!-- Bootstrap core CSS -->

    <meta name="viewport" content="width=device-width, initial-scale=1">
		<link href="../../css/pg_cabecera.css" rel="stylesheet">
    <link href="../../css/adm_cuerpo.css" rel="stylesheet">
    <link href="../../css/pg_slider.css" rel="stylesheet">
    <link href="../../css/formstyle.css" rel="stylesheet">



		<script src="js/jquery-3.1.1.min.js"></script>
		<script src="js/bootstrap.min.js"></script>	

    <link rel="canonical" href="https://getbootstrap.com/docs/5.0/examples/album/">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">

            
</head>
<body>

<?php include 'pg_slidebar.php'; ?>

    <section id="cuerpo">