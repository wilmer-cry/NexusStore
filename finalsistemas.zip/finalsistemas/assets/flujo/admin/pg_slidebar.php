
    <div class="sidebar">
        <br>
        <img width="90%" src="../../img/logo.png" alt="">
        <br>
        <br>
        <div><a href="../acciones/producto_mostrar_todos.php">Productos     </a></div>
        <div><a href="../acciones/categorias.php">            Categorias    </a></div>
        <div><a href="../acciones/producto_mostrar_todos.php">Subcategorias </a></div>
        <div><a href="../acciones/producto_mostrar_todos.php">Clientes      </a></div>
        <div><a href="../acciones/pedido.php">Pedidos       </a></div>
        <div><a href="../acciones/usuarios.php">usuarios      </a></div>
        <br>
    </div>    